# Student Task and Study Planner (MERN)

## Run locally
Requirements: Node.js 20+, MongoDB (local or Atlas), VS Code.

1. In `backend`, run `npm install`.
2. Copy `backend/.env.example` to `backend/.env`, then set `MONGO_URI` and a long random `JWT_SECRET`.
3. Run `npm run dev` in `backend`.
4. In a second terminal, go to `frontend`, run `npm install`, then `npm run dev`.
5. Open the Vite URL, normally http://localhost:5173.

## GitHub
Create an empty GitHub repository, then from this project folder:
```
git init
git add .
git commit -m "Initial Student Planner MERN project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-task-study-planner.git
git push -u origin main
```
Replace the remote URL with your own repository URL. Never upload `.env`.

## Deployment
Use MongoDB Atlas for the database, Render for the backend and Vercel for the frontend.
- Render root directory: `backend`; build: `npm install`; start: `npm start`.
- Set Render variables: `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL` (your Vercel URL), `NODE_ENV=production`.
- Vercel root directory: `frontend`; set `VITE_API_URL` to your Render URL plus `/api`.
- After deploying Vercel, update Render's `CLIENT_URL` and redeploy.

You must sign in to those services and complete deployment to obtain your own live links.
This is an educational starter. Review security and validation before using with real student data.
