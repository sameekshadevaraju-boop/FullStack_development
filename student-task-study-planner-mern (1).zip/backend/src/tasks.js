import {Router} from "express";
import {Task} from "./models.js";
import {protect} from "./middleware.js";
const router=Router();router.use(protect);
router.get("/",async(req,res)=>{
 try{
  const filter={user:req.userId};
  if(["Pending","In Progress","Completed"].includes(req.query.status))filter.status=req.query.status;
  if(req.query.search){const q=String(req.query.search).slice(0,80);filter.$or=[{title:{$regex:q,$options:"i"}},{subject:{$regex:q,$options:"i"}}];}
  res.json(await Task.find(filter).sort({dueDate:1,createdAt:-1}));
 }catch{res.status(500).json({message:"Could not load tasks."});}
});
router.post("/",async(req,res)=>{
 try{if(!String(req.body.title||"").trim())return res.status(400).json({message:"Task title is required."});
  const {title,subject,description,dueDate,priority}=req.body;
  res.status(201).json(await Task.create({user:req.userId,title,subject,description,dueDate:dueDate||null,priority}));
 }catch{res.status(400).json({message:"Please check the task details."});}
});
router.put("/:id",async(req,res)=>{
 try{const updates={};for(const k of ["title","subject","description","dueDate","priority","status"])if(k in req.body)updates[k]=req.body[k];
  const task=await Task.findOneAndUpdate({_id:req.params.id,user:req.userId},updates,{new:true,runValidators:true});
  if(!task)return res.status(404).json({message:"Task not found."});res.json(task);
 }catch{res.status(400).json({message:"Could not update task."});}
});
router.delete("/:id",async(req,res)=>{
 const task=await Task.findOneAndDelete({_id:req.params.id,user:req.userId});
 if(!task)return res.status(404).json({message:"Task not found."});res.json({message:"Task deleted."});
});
export default router;
