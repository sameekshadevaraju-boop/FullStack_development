import jwt from "jsonwebtoken";
export function protect(req,res,next){
 const header=req.headers.authorization||"";
 const token=header.startsWith("Bearer ")?header.slice(7):null;
 if(!token)return res.status(401).json({message:"Please log in first."});
 try{req.userId=jwt.verify(token,process.env.JWT_SECRET).id;next();}
 catch{return res.status(401).json({message:"Session expired. Please log in again."});}
}
