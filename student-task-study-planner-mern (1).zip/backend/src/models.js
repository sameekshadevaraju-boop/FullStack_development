import mongoose from "mongoose";
const userSchema = new mongoose.Schema({
 name:{type:String,required:true,trim:true,maxlength:80},
 email:{type:String,required:true,unique:true,lowercase:true,trim:true},
 password:{type:String,required:true}
},{timestamps:true});
const taskSchema = new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true,index:true},
 title:{type:String,required:true,trim:true,maxlength:120},
 subject:{type:String,default:"",trim:true},
 description:{type:String,default:"",maxlength:1000},
 dueDate:{type:Date,default:null},
 priority:{type:String,enum:["Low","Medium","High"],default:"Medium"},
 status:{type:String,enum:["Pending","In Progress","Completed"],default:"Pending"}
},{timestamps:true});
const sessionSchema = new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true,index:true},
 title:{type:String,required:true,trim:true},
 subject:{type:String,default:""},
 date:{type:Date,required:true},startTime:{type:String,required:true},
 duration:{type:Number,min:5,max:720,required:true},notes:{type:String,default:""}
},{timestamps:true});
export const User=mongoose.model("User",userSchema);
export const Task=mongoose.model("Task",taskSchema);
export const StudySession=mongoose.model("StudySession",sessionSchema);
