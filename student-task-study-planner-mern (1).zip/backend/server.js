import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import authRoutes from "./src/auth.js";
import taskRoutes from "./src/tasks.js";
import sessionRoutes from "./src/sessions.js";
dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());
app.get("/api/health", (_req,res)=>res.json({message:"Student Planner API is running"}));
app.use("/api/auth", authRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/sessions", sessionRoutes);
const port = process.env.PORT || 5000;
if (!process.env.MONGO_URI || !process.env.JWT_SECRET) {
  console.error("Set MONGO_URI and JWT_SECRET in backend/.env"); process.exit(1);
}
mongoose.connect(process.env.MONGO_URI)
 .then(()=>app.listen(port,()=>console.log(`API running on ${port}`)))
 .catch(e=>{console.error("MongoDB connection error:",e.message);process.exit(1)});
