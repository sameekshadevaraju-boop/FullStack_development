import {Router} from "express";
import {StudySession} from "./models.js";
import {protect} from "./middleware.js";
const router=Router();router.use(protect);
router.get("/",async(req,res)=>{
 try{res.json(await StudySession.find({user:req.userId}).sort({date:1,startTime:1}));}
 catch{res.status(500).json({message:"Could not load study sessions."});}
});
router.post("/",async(req,res)=>{
 try{const {title,subject,date,startTime,duration,notes}=req.body;
  if(!title||!date||!startTime||!duration)return res.status(400).json({message:"Title, date, time and duration are required."});
  res.status(201).json(await StudySession.create({user:req.userId,title,subject,date,startTime,duration,notes}));
 }catch{res.status(400).json({message:"Please check the session details."});}
});
router.delete("/:id",async(req,res)=>{
 const s=await StudySession.findOneAndDelete({_id:req.params.id,user:req.userId});
 if(!s)return res.status(404).json({message:"Session not found."});res.json({message:"Session deleted."});
});
export default router;
