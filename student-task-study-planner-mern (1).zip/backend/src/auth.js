import {Router} from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {User} from "./models.js";
import {protect} from "./middleware.js";
const router=Router();
const makeToken=id=>jwt.sign({id},process.env.JWT_SECRET,{expiresIn:"7d"});
router.post("/register",async(req,res)=>{
 try{
  const name=String(req.body.name||"").trim(),email=String(req.body.email||"").trim().toLowerCase(),password=String(req.body.password||"");
  if(!name||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<6)return res.status(400).json({message:"Enter your name, a valid email and a password of at least 6 characters."});
  if(await User.findOne({email}))return res.status(409).json({message:"This email is already registered."});
  const user=await User.create({name,email,password:await bcrypt.hash(password,12)});
  res.status(201).json({token:makeToken(user._id),user:{id:user._id,name:user.name,email:user.email}});
 }catch{return res.status(500).json({message:"Could not create account."});}
});
router.post("/login",async(req,res)=>{
 try{
  const email=String(req.body.email||"").trim().toLowerCase(),password=String(req.body.password||"");
  const user=await User.findOne({email});
  if(!user||!await bcrypt.compare(password,user.password))return res.status(401).json({message:"Incorrect email or password."});
  res.json({token:makeToken(user._id),user:{id:user._id,name:user.name,email:user.email}});
 }catch{return res.status(500).json({message:"Could not log in."});}
});
router.get("/me",protect,async(req,res)=>{
 const user=await User.findById(req.userId).select("name email");
 if(!user)return res.status(404).json({message:"User not found."});
 res.json({user:{id:user._id,name:user.name,email:user.email}});
});
export default router;
